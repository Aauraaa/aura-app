import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
const app=express(); const __dirname=path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({limit:'12mb'})); app.use(express.static(__dirname));
app.post('/api/analyze',async(req,res)=>{
  try{
    const key=process.env.OPENAI_API_KEY;
    if(!key)return res.status(503).json({error:'خدمة تحليل الصور غير مفعّلة بعد؛ يلزم إعداد مفتاح API على الخادم.'});
    const {image,mealName=''}=req.body||{};
    if(!image||!image.startsWith('data:image/'))return res.status(400).json({error:'الصورة غير صالحة.'});
    const response=await fetch('https://api.openai.com/v1/responses',{
      method:'POST',headers:{'Authorization':`Bearer ${key}`,'Content-Type':'application/json'},
      body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-4.1-mini',input:[{role:'user',content:[
        {type:'input_text',text:`حلل صورة الطعام باللغة العربية. اسم الوجبة المقترح: ${mealName||'غير محدد'}. قدّر المكونات والكميات الظاهرة والسعرات والبروتين والكربوهيدرات والدهون للحصة الظاهرة. لا تدّع الدقة التامة، واذكر عدم اليقين في الوصف. أعد JSON فقط بهذه المفاتيح: name (string), description (string), calories (number), protein (number grams), carbs (number grams), fat (number grams), ingredients (array of objects with name, estimated_amount, notes). لا تستنتج معلومات غير مرئية كأنها مؤكدة.`},
        {type:'input_image',image_url:image}
      ]}],text:{format:{type:'json_object'}}})
    });
    const payload=await response.json();
    if(!response.ok)return res.status(502).json({error:payload.error?.message||'فشل مزود تحليل الصور.'});
    const textOut=payload.output?.flatMap(x=>x.content||[]).find(x=>x.type==='output_text')?.text;
    if(!textOut)throw new Error('لم تصل نتيجة قابلة للقراءة.');
    res.json(JSON.parse(textOut));
  }catch(e){res.status(500).json({error:'تعذر تحليل الصورة حاليًا. حاول مرة أخرى.'});}
});
const port=process.env.PORT||3000;app.listen(port,()=>console.log(`Aura listening on ${port}`));
